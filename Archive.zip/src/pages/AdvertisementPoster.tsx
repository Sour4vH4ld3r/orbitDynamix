import React, { useRef } from 'react';
import { Shield, Lock, Award, CheckCircle, ArrowRight, Download, Share2, Star, Zap, Users, Globe, Smartphone, Monitor, Code, Rocket, Heart } from 'lucide-react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const AdvertisementPoster = () => {
  const heroPostRef = useRef<HTMLDivElement>(null);
  const instagramPostRef = useRef<HTMLDivElement>(null);
  const linkedinPostRef = useRef<HTMLDivElement>(null);
  const twitterPostRef = useRef<HTMLDivElement>(null);

  const downloadAsImage = async (elementRef: React.RefObject<HTMLDivElement>, filename: string) => {
    if (!elementRef.current) return;

    try {
      // Show loading state
      const loadingToast = document.createElement('div');
      loadingToast.innerHTML = '📸 Generating image...';
      loadingToast.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: linear-gradient(45deg, #06b6d4, #8b5cf6);
        color: white;
        padding: 12px 20px;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 600;
        z-index: 10000;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      `;
      document.body.appendChild(loadingToast);

      // Dynamically import html2canvas
      const html2canvas = (await import('html2canvas')).default;
      
      // Hide download buttons temporarily for cleaner capture
      const downloadButtons = elementRef.current.querySelectorAll('button');
      downloadButtons.forEach(btn => {
        if (btn.textContent?.includes('Download')) {
          btn.style.display = 'none';
        }
      });

      // Wait a moment for the DOM to update
      await new Promise(resolve => setTimeout(resolve, 200));
      
      // Capture with optimized settings
      const canvas = await html2canvas(elementRef.current, {
        useCORS: true,
        allowTaint: true,
        logging: false,
        width: elementRef.current.offsetWidth,
        height: elementRef.current.offsetHeight,
      });

      // Show download buttons again
      downloadButtons.forEach(btn => {
        if (btn.textContent?.includes('Download')) {
          btn.style.display = '';
        }
      });

      // Create and download the image
      const link = document.createElement('a');
      link.download = `${filename}.png`;
      link.href = canvas.toDataURL('image/png', 1.0);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      // Remove loading toast and show success
      document.body.removeChild(loadingToast);
      
      // Show success toast
      const successToast = document.createElement('div');
      successToast.innerHTML = `✅ Downloaded: ${filename}.png`;
      successToast.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: linear-gradient(45deg, #10b981, #059669);
        color: white;
        padding: 12px 20px;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 600;
        z-index: 10000;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      `;
      document.body.appendChild(successToast);
      
      // Auto-remove success toast after 3 seconds
      setTimeout(() => {
        if (document.body.contains(successToast)) {
          document.body.removeChild(successToast);
        }
      }, 3000);
      
    } catch (error) {
      console.error('Error downloading image:', error);
      
      // Show download buttons again in case of error
      const downloadButtons = elementRef.current?.querySelectorAll('button');
      downloadButtons?.forEach(btn => {
        if (btn.textContent?.includes('Download')) {
          btn.style.display = '';
        }
      });
      
      // Remove any existing toasts
      const existingToasts = document.querySelectorAll('[style*="position: fixed"][style*="top: 20px"]');
      existingToasts.forEach(toast => {
        if (document.body.contains(toast)) {
          document.body.removeChild(toast);
        }
      });
      
      // Show error toast
      const errorToast = document.createElement('div');
      errorToast.innerHTML = '❌ Error downloading image. Please try again.';
      errorToast.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: linear-gradient(45deg, #ef4444, #dc2626);
        color: white;
        padding: 12px 20px;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 600;
        z-index: 10000;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      `;
      document.body.appendChild(errorToast);
      
      setTimeout(() => {
        if (document.body.contains(errorToast)) {
          document.body.removeChild(errorToast);
        }
      }, 4000);
    }
  };

  const downloadAllImages = async () => {
    const posts = [
      { ref: heroPostRef, name: 'orbitdynamix-hero-post' },
      { ref: instagramPostRef, name: 'orbitdynamix-instagram-post' },
      { ref: linkedinPostRef, name: 'orbitdynamix-linkedin-post' },
      { ref: twitterPostRef, name: 'orbitdynamix-twitter-post' }
    ];

    for (const post of posts) {
      await downloadAsImage(post.ref, post.name);
      // Small delay between downloads
      await new Promise(resolve => setTimeout(resolve, 500));
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-indigo-900">
      <div className="container mx-auto px-4 py-16">
        
        {/* Hero Social Media Post */}
        <Card ref={heroPostRef} className="mb-12 bg-white shadow-2xl border-0 overflow-hidden max-w-2xl mx-auto">
          <CardContent className="p-0">
            {/* Header with gradient */}
            <div className="bg-gradient-to-r from-cyan-500 via-purple-500 to-pink-500 p-8 text-white text-center relative overflow-hidden">
              {/* Background patterns */}
              <div className="absolute inset-0 opacity-20">
                <div className="absolute top-4 left-4 w-16 h-16 border-2 border-white rounded-full"></div>
                <div className="absolute bottom-4 right-4 w-12 h-12 border-2 border-white rounded-full"></div>
                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-20 h-20 border border-white rounded-full"></div>
              </div>
              
              <div className="relative z-10">
                <div className="flex items-center justify-center mb-4">
                  <img src="/logo.svg" alt="OrbitDynamix" className="h-16 w-auto mr-4 filter brightness-0 invert" />
                  <div>
                    <h2 className="text-3xl font-bold">OrbitDynamix</h2>
                    <p className="text-cyan-100 text-sm font-medium">INNOVATE • CREATE • ELEVATE</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Main content */}
            <div className="p-8 text-center">
              <div className="mb-6">
                <span className="inline-block bg-gradient-to-r from-cyan-500 to-purple-500 text-white px-6 py-2 rounded-full text-sm font-bold">
                  🚀 TRANSFORMING DIGITAL EXPERIENCES
                </span>
              </div>

              <h1 className="text-4xl font-bold text-gray-900 mb-4 leading-tight">
                Your Vision,<br />
                <span className="bg-gradient-to-r from-cyan-500 to-purple-500 bg-clip-text text-transparent">Our Innovation</span>
              </h1>

              <p className="text-gray-600 text-lg mb-8 max-w-lg mx-auto">
                From cutting-edge web development to powerful mobile apps - we bring your digital dreams to life
              </p>

              {/* Services icons */}
              <div className="grid grid-cols-4 gap-4 mb-8 max-w-md mx-auto">
                <div className="flex flex-col items-center p-3 bg-gradient-to-br from-cyan-50 to-cyan-100 rounded-xl">
                  <Monitor className="w-6 h-6 text-cyan-600 mb-1" />
                  <span className="text-xs font-semibold text-cyan-800">Web</span>
                </div>
                <div className="flex flex-col items-center p-3 bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl">
                  <Smartphone className="w-6 h-6 text-purple-600 mb-1" />
                  <span className="text-xs font-semibold text-purple-800">Mobile</span>
                </div>
                <div className="flex flex-col items-center p-3 bg-gradient-to-br from-pink-50 to-pink-100 rounded-xl">
                  <Code className="w-6 h-6 text-pink-600 mb-1" />
                  <span className="text-xs font-semibold text-pink-800">Custom</span>
                </div>
                <div className="flex flex-col items-center p-3 bg-gradient-to-br from-indigo-50 to-indigo-100 rounded-xl">
                  <Rocket className="w-6 h-6 text-indigo-600 mb-1" />
                  <span className="text-xs font-semibold text-indigo-800">Launch</span>
                </div>
              </div>

              <Button className="bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600 text-white px-8 py-3 text-lg font-semibold rounded-full shadow-lg transform hover:scale-105 transition-all">
                Start Your Project
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </div>

            {/* Footer */}
            <div className="bg-gray-50 p-4 text-center border-t">
              <p className="text-gray-600 text-sm">
                <Globe className="inline w-4 h-4 mr-1" />
                orbitdynamix.com | 
                <span className="ml-2">📧 contact@orbitdynamix.com</span>
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Instagram Square Post */}
        <Card ref={instagramPostRef} className="mb-12 bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600 border-0 shadow-2xl overflow-hidden max-w-lg mx-auto" style={{aspectRatio: '1/1'}}>
          <CardContent className="p-8 h-full flex flex-col justify-between text-white text-center">
            <div>
              <div className="flex items-center justify-center mb-6">
                <img src="/logo.svg" alt="OrbitDynamix" className="h-12 w-auto mr-3 filter brightness-0 invert" />
                <span className="text-2xl font-bold">OrbitDynamix</span>
              </div>
              
              <div className="bg-white/20 backdrop-blur-sm rounded-2xl p-6 mb-6">
                <Zap className="w-12 h-12 mx-auto mb-4" />
                <h2 className="text-2xl font-bold mb-3">
                  Ready to Go Digital?
                </h2>
                <p className="text-white/90 text-sm">
                  We create stunning websites, powerful apps, and digital solutions that drive results
                </p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex justify-center space-x-4 text-sm">
                <span className="bg-white/20 px-3 py-1 rounded-full">#WebDev</span>
                <span className="bg-white/20 px-3 py-1 rounded-full">#MobileApp</span>
                <span className="bg-white/20 px-3 py-1 rounded-full">#DigitalSolutions</span>
              </div>
              
              <Button className="bg-white text-purple-600 hover:bg-gray-100 px-8 py-2 rounded-full font-bold w-full">
                Get Started Today
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* LinkedIn Professional Post */}
        <Card ref={linkedinPostRef} className="mb-12 bg-white border shadow-xl max-w-2xl mx-auto">
          <CardContent className="p-6">
            {/* Header */}
            <div className="flex items-center mb-6">
              <img src="/logo.svg" alt="OrbitDynamix" className="h-12 w-auto mr-4" />
              <div>
                <h3 className="text-xl font-bold text-gray-900">OrbitDynamix</h3>
                <p className="text-gray-500 text-sm">Digital Innovation Company • Following</p>
              </div>
            </div>

            {/* Content */}
            <div className="mb-6">
              <p className="text-gray-800 text-lg leading-relaxed mb-4">
                🚀 <strong>Exciting times ahead!</strong> We're helping businesses transform their digital presence with cutting-edge solutions.
              </p>
              
              <div className="bg-gradient-to-r from-cyan-50 to-purple-50 p-6 rounded-xl mb-4 border border-cyan-200">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-cyan-600">50+</div>
                    <div className="text-gray-600 text-sm">Projects</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-purple-600">100%</div>
                    <div className="text-gray-600 text-sm">Satisfaction</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-pink-600">24/7</div>
                    <div className="text-gray-600 text-sm">Support</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-indigo-600">Fast</div>
                    <div className="text-gray-600 text-sm">Delivery</div>
                  </div>
                </div>
              </div>

              <p className="text-gray-700 mb-4">
                Whether you need a stunning website, a powerful mobile app, or custom software solutions - we've got you covered!
              </p>
              
              <div className="flex flex-wrap gap-2 mb-4">
                <Badge className="bg-cyan-100 text-cyan-800">#WebDevelopment</Badge>
                <Badge className="bg-purple-100 text-purple-800">#MobileApps</Badge>
                <Badge className="bg-pink-100 text-pink-800">#DigitalTransformation</Badge>
                <Badge className="bg-indigo-100 text-indigo-800">#TechSolutions</Badge>
              </div>
            </div>

            {/* Engagement */}
            <div className="border-t pt-4">
              <div className="flex justify-between text-gray-500 text-sm">
                <button className="flex items-center space-x-2 hover:text-cyan-600 transition-colors">
                  <Heart className="w-4 h-4" />
                  <span>Like</span>
                </button>
                <button className="flex items-center space-x-2 hover:text-cyan-600 transition-colors">
                  <span>💬</span>
                  <span>Comment</span>
                </button>
                <button className="flex items-center space-x-2 hover:text-cyan-600 transition-colors">
                  <Share2 className="w-4 h-4" />
                  <span>Share</span>
                </button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Twitter/X Post */}
        <Card ref={twitterPostRef} className="mb-12 bg-white border shadow-xl max-w-xl mx-auto">
          <CardContent className="p-6">
            <div className="flex items-start space-x-3 mb-4">
              <img src="/logo.svg" alt="OrbitDynamix" className="h-12 w-12 rounded-full bg-gradient-to-r from-cyan-400 to-purple-400 p-2" />
              <div className="flex-1">
                <div className="flex items-center space-x-2 mb-2">
                  <h4 className="font-bold text-gray-900">OrbitDynamix</h4>
                  <span className="text-cyan-500">✓</span>
                  <span className="text-gray-500 text-sm">@orbitdynamix • 3h</span>
                </div>
                
                <div className="text-gray-900 text-lg leading-relaxed">
                  <p className="mb-3">
                    🌟 Transform your business with our digital solutions! From web development to mobile apps, we bring innovation to life.
                  </p>
                  
                  <div className="bg-gradient-to-r from-cyan-50 to-purple-50 p-4 rounded-xl border border-cyan-200 mb-3">
                    <p className="text-gray-800 font-semibold text-center">
                      💡 Ready to innovate? Let's build something amazing together!
                    </p>
                  </div>
                  
                  <p className="text-cyan-600">
                    #DigitalInnovation #WebDev #MobileApps #OrbitDynamix #TechSolutions
                  </p>
                </div>
              </div>
            </div>

            <div className="flex justify-between text-gray-500 text-sm border-t pt-4">
              <button className="flex items-center space-x-2 hover:text-cyan-600">
                <span>💬</span>
                <span>Reply</span>
              </button>
              <button className="flex items-center space-x-2 hover:text-green-600">
                <span>🔄</span>
                <span>Retweet</span>
              </button>
              <button className="flex items-center space-x-2 hover:text-red-600">
                <Heart className="w-4 h-4" />
                <span>Like</span>
              </button>
              <button className="flex items-center space-x-2 hover:text-cyan-600">
                <Share2 className="w-4 h-4" />
                <span>Share</span>
              </button>
            </div>
          </CardContent>
        </Card>

        {/* Footer Message */}
        <div className="text-center">
          <p className="text-white/70 text-lg">
            ✨ Professional social media designs for OrbitDynamix
          </p>
        </div>
      </div>
    </div>
  );
};

export default AdvertisementPoster;